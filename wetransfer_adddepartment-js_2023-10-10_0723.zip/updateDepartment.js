
$(document).ready(() => {

    $('#eaemail').hide();
    $('#addemail').hide();
  
    // Bind an event handler to the change event of the dropdown
    $('#ea').change(function(){
  
        // Check the selected value
        var selectedValue = $("#ea").val(); 
        // If "No" is selected, hide the input field  with button; otherwise, show it
        if(selectedValue === 'N'){
          
            $('#eaemail').hide();
            $("#addemail").hide();
        } else {
            $('#eaemail').show();
            $("#addemail").show();
  
        }
    });
      $('#hodemail').hide();
      $('#addemail1').hide();
  
  
    $('#hod').change(function(){
  
      // Check the selected value
      var selectedValue = $("#hod").val(); 
      // If "No" is selected, hide the input field  with button; otherwise, show it
      if(selectedValue === 'N'){
  
          $('#hodemail').hide();
            $("#addemail1").hide();
      } else {
          $('#hodemail').show();
            $("#addemail1").show();
  
      }
  });
  
    const token = JSON.parse(localStorage.getItem("token"));
    var test = $.test()

    var sessionString = sessionStorage.getItem('objectdata');
    var object = JSON.parse(sessionString);
    console.log("obejct", object)
    console.log(object[0].emails)

    $("#input-text1").val(object[0].departmentCode);
    $("#input-text2").val(object[0].departmentName);
    $("#input-text4").val(object[0].e_A);
    $("#input-text5").val(object[0].hod);
    $("#input-text3").val(object[0].name);

    var emailArr = object[0].emails.map(value=>value.email);
    console.log('emailArr ---->' ,emailArr);
    let newOption1;

    emailArr.map((item) => {
        $("#DropDown").append(`<option value="${item}">${item}</option>`)
    });
    
    let selectedFilter = $("#DropDown").filterMultiSelect({
        placeholderText: "Nothing Selected"
      });

      selectedFilter.selectAll();


    $("#addEmail").click(function () {
        let emailVal = $("#input-text6").val();

        if (emailVal !== "") {

            if(emailArr.includes(emailVal) ==  false)
            {
            
            newOption1 = []
            emailArr.push(emailVal)

            console.log("entered");
            $('#DropDown').remove();
            emailArr.map((value)=> {
              console.log(value);
              newOption1.push($('<option>', { value: `${value}`, text: `${value}` }));
            })
            
              // $("#DropDown").append(`<option value="${emailVal}">${emailVal}</option>`)
              $("#input-text6").val("")
              // emailArr.push({ 'email': emailVal });
              $("#dropId").append(`<select id="DropDown" name="emails" multiple class="form-control">
              </select>`)
              $('#DropDown').append(...newOption1)
               selectedFilter = $("#DropDown").filterMultiSelect({
                placeholderText: "Nothing Selected"
              })

              selectedFilter.selectAll()

                // $("#DropDown").append(`<option value="${emailVal}">${emailVal}</option>`)
                // $("#input-text6").val("")
            }
            // emailArr.push({ 'email': emailVal });
        }

        
    });


    



   
    $("#form").submit((e) => {

        e.preventDefault();
        let emails = []

        let values  = selectedFilter.getSelectedOptionsAsJson(includeDisabled=true);

              JSON.parse(values).emails.map(values => {
                emails.push({email : values});
              })

        // console.log(JSON.stringify({
        //     departmentCode: $("#input-text1").val(),
        //     departmentName: $("#input-text2").val(),
        //     e_A: $("#input-text4").val(),
        //     hod: $("#input-text5").val(),
        //     name: $("#input-text3").val(),
        //     emails : emails
        // }));




        $.ajax({
            type: "PUT",
            url: `${[test[0].url]}/department/update?id=${object[0].id}`,

            data: JSON.stringify({
                departmentCode: $("#input-text1").val(),
                departmentName: $("#input-text2").val(),
                e_A: $("#input-text4").val(),
                hod: $("#input-text5").val(),
                name: $("#input-text3").val(),

                emails: emails
            }),

            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + token,

            },
            success: function (data, status, xhr) {
                console.log(data);

                if (xhr.status == 200) {
                    const swalWithBootstrapButtons = Swal.mixin({
                        customClass: {
                            confirmButton: 'btn btn-primary',
                        },
                        buttonsStyling: false
                    })


                    swalWithBootstrapButtons.fire({
                        title: 'Department  updated',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        reverseButtons: true
                    }).then((result) => {

                        window.open("../template/department.jsp", "_self")
                    })
                }
                else {

                    $.errorMessage(xhr.responseJSON.message);
                }


            },
            error: function (xhr) {
                if (xhr.status == 498) {
                    $.tokenError();
                }
                else if (xhr.status >= 400 && xhr.status < 500) {

                    $.errorMessage(xhr.responseJSON.message);
                }
                else {
                    $.errorMessage(xhr.responseJSON.error)
                }
            },
        });
    });



    $(".cancel").click(() => {
        window.open("../template/department.jsp", "_self")
    })

})

