$(document).ready(() => {

    const token = JSON.parse(localStorage.getItem("token"));
    var test = $.test()

    var sessionString = sessionStorage.getItem('object');
    var object = JSON.parse(sessionString);

    console.log(object[0]);

    var product_details = object[0].ibShipmentDtl

    let fieldNames = ['sequenceNumber', 'itemCode', 'description', 'hsn', 'uom', 'quantity', 'unit']

    var total_rows = 0;

    const fillTableRows = () => {

        for (let i = 0; i < product_details.length; i++) {
            console.log(product_details[i])
            fetchRow(product_details[i])
        }

    }
    fillTableRows()

    function fetchRow(item) {

        let newRow = $(`<tr id="row_${total_rows}">`)

        for (let i = 0; i < fieldNames.length; i++) {
            let cell = $('<td>')
            let field = $(`<input type="text" class="form-control px-1 input_size check" required="" id="${fieldNames[i]}_${total_rows}" value=${item[fieldNames[i]]} />`)
            cell.append(field)
            newRow.append(cell)
        }

        let btnCell = $(`<td>
        <button type="button" class="btn btn-outline-danger cancelButton"> Cancel </button> </td>`)
        newRow.append(btnCell)

        $('#product-table tbody').append(newRow)

        total_rows++;
    }

    function addRow() {





        let newRow = $(`<tr id="row_${total_rows}">`)

        for (let i = 0; i < fieldNames.length; i++) {
            let cell = $('<td>')
            let field = $(`<input type="text" class="form-control px-1 input_size check" required="" id="${fieldNames[i]}_${total_rows}" />`)
            cell.append(field)
            newRow.append(cell)
        }

        let btnCell = $(`<td>
        <button type="button" class="btn btn-outline-danger cancelButton"> Cancel </button> </td>`)
        newRow.append(btnCell)

        $('#product-table tbody').append(newRow)
        total_rows++;
    }

    $("#addButton").on("click", function () {
       validationRow();    
    })


    function validationRow() {
        // alert("ho")
        let isValid = true;
        // Example: Check if a specific input field is not empty
        let sequenceNumber = $(`#sequenceNumber_${$("#product-table tbody tr").length - 1}`).val().trim();
        let itemCode = $(`#itemCode_${$("#product-table tbody tr").length - 1}`).val().trim();
        let description = $(`#description_${$("#product-table tbody tr").length - 1}`).val().trim();
        let uom = $(`#uom_${$("#product-table tbody tr").length - 1}`).val().trim();
        let quantity = $(`#quantity_${$("#product-table tbody tr").length - 1}`).val().trim();
        let unit = $(`#unit_${$("#product-table tbody tr").length - 1}`).val().trim();
    
          // Check if at least one field is not empty
          if (sequenceNumber !== "" || itemCode !== "" || description !== "" || uom !== "" || quantity !== "" || unit !== "") {

            isValid = true;
            addRow(); // Call addRow only if at least one field is filled
        } else {
            // alert("Please Fill Row");
        }
    }

   
    $("#product-table").on('click', '.cancelButton', function () {
        // Check if there's only one row left in the table
        if ($("#product-table tbody tr").length > 1) {
            // Remove the closest row
            $(this).closest("tr").remove();
            total_rows--;
        } else {
            // Show a message or take some action to indicate that at least one row must remain
            // alert('At least one row must remain in the table!');
        }
    });


    function extractTableInputValues() {
        let dataObjects = []

        $('#product-table tbody tr').each(function () {
            let rowData = {}
            $(this).find('input').each(function (index) {
                let columnName = fieldNames[index];
                let cellValue = $(this).val();
                rowData[columnName] = cellValue;
            })
            dataObjects.push(rowData)
        })

        return dataObjects
    }

    $("#invoicenumber").val(object[0].invoiceNumber)
    $("#invoicedate").val(object[0].invoiceDate)
    $("#dc_number").val(object[0].deliveryChallanNumber)
    $("#workorderno").val(object[0].workOrderNumber)
    $("#ponumber").val(object[0].poNumber)
    $("#potype").val(object[0].poType)
    $("#weightquantity").val(object[0].weight)
    $("#invoiceamount").val(object[0].invoiceAmount)
    $("#lrnumber").val(object[0].lrNumber)
    $("#lrdate").val(object[0].lrDate)
    $("#contractnumber").val(object[0].contractNumber)
    $("#contractdate").val(object[0].contractDate)
    $("#state").val(object[0].state)
    $("#ewaybillno").val(object[0].ewayBillNumber)
    $("#irnno").val(object[0].irnNumber)
    $("#cgstrate").val(object[0].cgstPercentage)
    $("#cgstamount").val(object[0].cgstAmount)
    $("#sgstrate").val(object[0].sgstPercentage)
    $("#sgstamount").val(object[0].sgstAmount)
    $("#igstrate").val(object[0].igstPercentage)
    $("#igstamount").val(object[0].igstAmount)
    $("#cessrate").val(object[0].cessPercentage)
    $("#cessamount").val(object[0].cessAmount)
    $("#taxablevalue").val(object[0].taxableValue)


   

    $("#updateForm").submit(function(e) {
        // alert("hlo mansi")
        product_details=extractTableInputValues()

        e.preventDefault();
      

        let req_body = {

            invoiceNumber: $("#invoicenumber").val(),
            invoiceDate: $("#invoicedate").val(),
            deliveryChallanNumber: $("#dc_number").val(),
            workOrderNumber: $("#workorderno").val(),
            poNumber: $("#ponumber").val(),
            poType: $("#potype").val(),
            weight: $("#weightquantity").val(),
            invoiceAmount: $("#invoiceamount").val(),
            lrNumber: $("#lrnumber").val(),
            lrDate: $("#lrdate").val(),
            contractNumber: $("#contractnumber").val(),
            contractDate: $("#contractdate").val(),
            state: $("#state").val(),
            ewayBillNumber: $("#ewaybillno").val(),
            irnNumber: $("#irnno").val(),
            cgstPercentage: $("#cgstrate").val(),
            cgstAmount: $("#cgstamount").val(),
            sgstPercentage: $("#sgstrate").val(),
            sgstAmount: $("#sgstamount").val(),
            igstPercentage: $("#igstrate").val(),
            igstAmount: $("#igstamount").val(),
            cessPercentage: $("#cessrate").val(),
            cessAmount: $("#cessamount").val(),
            taxableValue: $("#taxablevalue").val(),
            ibShipmentDtl: product_details,
        }

        console.log(req_body);
        console.log();
        $.ajax({
            type: "PUT",
            url: `http://192.168.50.81:8080/ap_automation_backend/ibshipment/update?id=${object[0].id}`,

            data: JSON.stringify(req_body),

            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
                
            },
            success: function (data, status, xhr) {
                
                console.log("data    :",data);

                if (xhr.status == 200) {
                    const swalWithBootstrapButtons = Swal.mixin({
                        customClass: {
                            confirmButton: 'btn btn-primary',
                        },
                        buttonsStyling: false
                    })


                    swalWithBootstrapButtons.fire({
                        title: 'Inbound  updated',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        reverseButtons: true
                    }).then((result) => {
                        console.log(data);

                        window.open("../template/Inbound.jsp", "_self")
                    })
                }
                else {

                    $.errorMessage(xhr.responseJSON.message);
                }


            },
            error: function (xhr) {
                console.log("xhr : ",xhr)
                if (xhr.status == 498) {
                    $.tokenError();
                }
                else if (xhr.status >= 400 && xhr.status < 500) {

                    $.errorMessage(xhr.responseJSON.message);
                }
                else {
                    $.errorMessage(xhr.responseJSON.error)
                }
            },
        });
    });


    $("#cancelButton").click(function(e) {
        e.preventDefault(); // Prevent the default form submission
        // Add any additional logic or actions you want here
        window.open("../template/Inbound.jsp", "_self");

    });

})
