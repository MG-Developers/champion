
    $(document).ready(function () {
        const container = $("#duplicatedDivContainer");
        let counter = 1;

        $("#addButton").on("click", function () {
            const originalDiv = $("#product-details");
            const clonedDiv = originalDiv.clone(true);

            const uniqueID = `Form-${counter}`;
            clonedDiv.attr("id", uniqueID);

            const inputUnique = `input-${counter}`;
            const inputElements = clonedDiv.find('input');

            inputElements.each(function (index, element) {
                if ($(element).prop('tagName') === 'INPUT') {
                    $(element).val('');
                }
            });

            inputElements.each(function (index, input) {
                const inputID = `${inputUnique}-${index}`;
                $(input).attr('id', inputID);
            });

            const cancelBtn = clonedDiv.find("#cancel-div");
            cancelBtn.on("click", function () {
                console.log('cancel')
                clonedDiv.remove();
                        });

            container.append(clonedDiv);

            counter++;
        });

        const submitButton = $("#mysubmitButton");
        let dataArray = [];
        let allfields = true;

        submitButton.on("click", function () {
            const inputs = $("#product-details");

            inputs.each(function (index, container) {
                let inputElements = $(container).find('input, select');
                let formData = {};
                let fieldCount = 0;

                inputElements.each(function (inputIndex, input) {
                    if ($(input).prop("tagName") === "SELECT") {
                        if ($(input).val() !== "Select") {
                            allfields = true;
                            formData[$(input).attr("id")] = $(input).val();
                        } else {
                            allfields = false;
                        }
                    } else {
                        const trimmedValue = $(input).val().trim();
                        if (trimmedValue !== "") {
                            formData[$(input).attr("id")] = trimmedValue;
                        } else {
                            allfields = false;
                        }
                    }
                    fieldCount++;

                    if (fieldCount === 7) {
                        if (Object.keys(formData).length > 0) {
                            dataArray.push(formData);
                        }
                        formData = {};
                        fieldCount = 0;
                    }
                });

                if (fieldCount > 0) {
                    if (Object.keys(formData).length > 0) {
                        dataArray.push(formData);
                    }
                }
            });

            dataArray = dataArray.filter((obj) => Object.keys(obj).length > 0);

            if (allfields && dataArray.length > 0) {
                console.log(dataArray);
                dataArray = [];
            } else {
                alert("Please fill in all fields before submitting.");
                dataArray = [];
            }
        });
    });
