{
    "data": {
      "content": [
        {
          "userid": 1129,
          "username": "Finance01",
          "password": "$2a$10$OeH0vM71Gx1PqV.B4ADtXeAE1nLfPDfmqpNp/YtqJwMicbab3y2qS",
          "first_name": "Finance01",
          "last_name": "Finance01",
          "address_number": 123,
          "display_name": null,
          "email": "ravinder.singh@kirtitec.com",
          "business_unit": null,
          "company_code": null,
          "mobileNumber": null,
          "gate_id": "GATE01-Inward",
          "store_id": null,
          "assignstore": [
            {
              "id": 21,
              "storeCode": "Main Store",
              "store_name": "Main Store",
              "companyInfo": {
                "id": 268,
                "company": "40000004",
                "doc_company": "20100",
                "gstin": null,
                "name": "RSB UNIT - I",
                "unitName": "RSB UNIT - I",
                "state_location": "Jharkhand",
                "businessUnit": "20100"
              }
            },
        },

        {
          "userid": 1212,
          "username": "10006457",
          "password": "$2a$10$qOxi.JWxxZ7AUGxmH2sGOOTL2XBbBXCtd5Ay1hbD7kKwqf.RlOumG",
          "first_name": "Neha ",
          "last_name": "Kumari",
          "address_number": 123,
          "display_name": null,
          "email": "rsbun1.store@rsbglobal.com",
          "business_unit": null,
          "company_code": null,
          "mobileNumber": null,
          "gate_id": "GATE01-Inward",
          "store_id": null,
          "assignstore": [
            {
              "id": 21,
              "storeCode": "Main Store",
              "store_name": "Main Store",
              "companyInfo": {
                "id": 268,
                "company": "40000004",
                "doc_company": "20100",
                "gstin": null,
                "name": "RSB UNIT - I",
                "unitName": "RSB UNIT - I",
                "state_location": "Jharkhand",
                "businessUnit": "20100"
              }
            },
            {
              "id": 1,
              "storeCode": "STORE01",
              "store_name": "STORE01",
              "companyInfo": {
                "id": 268,
                "company": "40000004",
                "doc_company": "20100",
                "gstin": null,
                "name": "RSB UNIT - I",
                "unitName": "RSB UNIT - I",
                "state_location": "Jharkhand",
                "businessUnit": "20100"
              }
            },
            {
              "id": 23,
              "storeCode": "R.M Yard",
              "store_name": "R.M Yard",
              "companyInfo": {
                "id": 268,
                "company": "40000004",
                "doc_company": "20100",
                "gstin": null,
                "name": "RSB UNIT - I",
                "unitName": "RSB UNIT - I",
                "state_location": "Jharkhand",
                "businessUnit": "20100"
              }
            },
            {
              "id": 22,
              "storeCode": "B/O Store",
              "store_name": "B/O Store",
              "companyInfo": {
                "id": 268,
                "company": "40000004",
                "doc_company": "20100",
                "gstin": null,
                "name": "RSB UNIT - I",
                "unitName": "RSB UNIT - I",
                "state_location": "Jharkhand",
                "businessUnit": "20100"
              }
            },
            {
              "id": 24,
              "storeCode": "Job Offloading",
              "store_name": "Job Offloading",
              "companyInfo": {
                "id": 268,
                "company": "40000004",
                "doc_company": "20100",
                "gstin": null,
                "name": "RSB UNIT - I",
                "unitName": "RSB UNIT - I",
                "state_location": "Jharkhand",
                "businessUnit": "20100"
              }
            },
            {
              "id": 25,
              "storeCode": "Maintenance",
              "store_name": "Maintenance",
              "companyInfo": {
                "id": 268,
                "company": "40000004",
                "doc_company": "20100",
                "gstin": null,
                "name": "RSB UNIT - I",
                "unitName": "RSB UNIT - I",
                "state_location": "Jharkhand",
                "businessUnit": "20100"
              }
            },
            {
              "id": 26,
              "storeCode": "Transportation",
              "store_name": "Transportation",
              "companyInfo": {
                "id": 268,
                "company": "40000004",
                "doc_company": "20100",
                "gstin": null,
                "name": "RSB UNIT - I",
                "unitName": "RSB UNIT - I",
                "state_location": "Jharkhand",
                "businessUnit": "20100"
              }
            }
          ],
          "assignroles": [
            {
              "roleid": 121,
              "rolecode": "GATE",
              "role_description": "Gate"
            },
            {
              "roleid": 248,
              "rolecode": "Unload",
              "role_description": "Unload"
            }
          ],
          "assigncompany": [
            {
              "id": 268,
              "company": "40000004",
              "doc_company": "20100",
              "gstin": null,
              "name": "RSB UNIT - I",
              "unitName": "RSB UNIT - I",
              "state_location": "Jharkhand",
              "businessUnit": "20100"
            }
          ]
        },
        
      ],
      "pageable": {
        "sort": {
          "empty": false,
          "sorted": true,
          "unsorted": false
        },
        "offset": 25,
        "pageNumber": 1,
        "pageSize": 25,
        "unpaged": false,
        "paged": true
      },
      "last": false,
      "totalPages": 4,
      "totalElements": 87,
      "size": 25,
      "number": 1,
      "sort": {
        "empty": false,
        "sorted": true,
        "unsorted": false
      },
      "numberOfElements": 25,
      "first": false,
      "empty": false
    },
    "message": "Successfully retrieved data!",
    "status": 200
  }