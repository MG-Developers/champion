$(document).ready(function () {
  
  const token = JSON.parse(localStorage.getItem("token"));

  var test = $.test();
  var dataTable = $("#myDataTable").DataTable({

    search: {
      return: true // Enable enter key search
    },

    ajax: {
      url: `http://192.168.50.81:8080/ap_automation_backend/usermaster/users`,
      type: "GET",
      headers: {
        Authorization: "Bearer " + token,
      },
      dataFilter: function (data) {

        var json = JSON.parse(data);
        json.recordsTotal = json.data.totalElements;
        json.recordsFiltered = json.data.totalElements;
        data_length = json.data.totalElements
        
        json.data = json.data.content;
        
        json.pageLength = json.data.numberOfElements
        console.log("JSON DATA" ,json)

        return JSON.stringify(json);
      },


      data: function (data) {
        console.log("page number" , (data.start / data.length));
        console.log("page LENGTH" , data.length);
        

        data.page = (data.start / data.length);
        data.size = data.length;

        // if (data.order.length > 0) {
        //   data.sortField = data.columns[data.order[0].column].data;
        //   data.sortDirection = data.order[0].dir;
        // }

        data.search = data.search.value
      },

      
    },

    columns: [
      { data: "userid" },
      { data: "username" },
      { data: "address_number" },
      { data: "email" },
      {
        data: "userid",
        render: function (data, type, row, meta) {
          return `
                    <div class="btn-group">
                        <button class='btn btn-outline-danger btn-sm delete'>Delete</button>&nbsp;&nbsp;  
                        <button class='btn btn-outline-success btn-sm edit'>Edit</button>&nbsp;&nbsp;
                        <button class='btn btn-outline-success btn-sm view'>View</button>
                    </div>
                `;
        },
      },
    ],
    columnDefs: [
      {
          targets: [0], // Target the first column (userid)
          visible: false, // Set visibility to false to hide the column
      },
  ],

  
    processing: true,
    serverSide: true,
    lengthMenu: [10, 25, 50, 75, 100],
    pageLength: 10,
   
    
   
  });


  dataTable.on("click", ".delete", function () {
    // Get the row data and perform delete operation
    const raw = $(this).closest("tr").children();
    const row = dataTable.row(raw).data().userid;

    // Display a confirmation dialog using Swal (SweetAlert2)
    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: 'btn btn-sm btn-success mx-1',
        cancelButton: 'btn btn-sm btn-danger mx-1'
      },
      buttonsStyling: false
    });

    swalWithBootstrapButtons.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Delete',
      cancelButtonText: 'Cancel',
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {
        // Perform the delete operation using AJAX
        $.ajax({
          url: `${[test[0].url]}/usermaster/deleteuser/${row}`,
          type: "delete",
          headers: {
            'Authorization': 'Bearer ' + token,
          },
          success: function (data, status, xhr) {

            console.log(xhr)
            if (xhr.status == 200) {
              // Display success message and reload the DataTable

              swalWithBootstrapButtons.fire({
                title: '',
                text: `${xhr.responseJSON.message}`,
                icon: 'success',
                confirmButtonText: 'OK',
              }).then(() => {
                dataTable.ajax.reload();       
                     });


            }
            else {

              $.errorMessage(xhr.responseJSON.message);
            }
          },
          error: function (xhr) {
            if (xhr.status == 498) {
              $.tokenError();
            }
            else if (xhr.status >= 400 && xhr.status < 500) {

              $.errorMessage(xhr.responseJSON.message);
            }
            else {
              $.errorMessage(xhr.responseJSON.error)
            }
          }
        });
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        swalWithBootstrapButtons.fire('Cancelled', 'Your Data is safe :(');
      }
    });
  });

  // Edit button click event handler
  dataTable.on("click", ".edit", function () {
    // Get the row data and redirect to update page
    const raw = $(this).closest("tr").children();
    const row = dataTable.row(raw).data().userid;
    $.ajax({
      url: `${[test[0].url]}/usermaster/users/${row}`,
      dataSrc: "data",
      headers: {
        'Authorization': 'Bearer ' + token,
      },
      success: function (data, status, xhr) {
        if (xhr.status == 200) {
          sessionStorage.setItem('object', JSON.stringify(data.data));
          window.location.href = `../template/updateUser.jsp`;
        }
        else {

          $.errorMessage(xhr.responseJSON.message);
        }
      },
      error: function (xhr) {
        if (xhr.status == 498) {
          $.tokenError();
        }
        else if (xhr.status >= 400 && xhr.status < 500) {

          $.errorMessage(xhr.responseJSON.message);
        }
        else {
          $.errorMessage(xhr.responseJSON.error)
        }
      }
    });
  });

  // View button click event handler
  dataTable.on("click", ".view", function () {
    // Get the row data and display in a modal
    const raw = $(this).closest("tr").children();
    const row = dataTable.row(raw).data().userid;
    $('#myModal5').modal('show');

    // Fetch user data using AJAX and populate the modal fields
    $.ajax({
      url: `${[test[0].url]}/usermaster/users/${row}`,
      dataSrc: "data",
      headers: {
        'Authorization': 'Bearer ' + token,
      },
      success: function (data, status, xhr) {
        if (xhr.status == 200) {

          $("#input-text11").text(`${data.data.first_name}`);
          $("#input-text12").text(data.data.username);
          $("#form6Example3").val(data.data.first_name).css("font-weight", "bold");
          $("#form6Example4").val(data.data.last_name).css("font-weight", "bold");
          $("#form6Example10").val(data.data.role_ids).css("font-weight", "bold");
          $("#form6Example5").val(data.data.address_number).css("font-weight", "bold");
          $("#gate_id").val(data.data.gate_id).css("font-weight", "bold");
          $("#input-text13").text(data.data.email);

          // Display assigned roles or a message if none
          if (data.data.assignroles.length === 0) {
            $("#countries").append(`<p class="border p-2 bg-primary">NO ROLE ASSIGNED</p>`);
          } else {
            data.data.assignroles.forEach((value) => {
              $("#countries").append(`<button type="button" class="btn btn-success my-1 mx-1">${value.rolecode}</button>`);
            });
          }
          if (data.data.assigncompany.length === 0) {
            $("#unitname").append(`<p class="border p-2 bg-primary">NO UNIT NAME ASSIGNED</p>`);
          } else {
            data.data.assigncompany.forEach((value) => {
              // console.log(value);
              $("#unitname").append(`<button type="button" class="btn btn-success my-1 mx-1">${value.unitName}</button>`);
            });
          }
        }
        else {

          $.errorMessage(xhr.responseJSON.message);
        }
        // console.log(data.data);
        // Update modal fields with user data
      },
      error: function (xhr) {
        if (xhr.status == 498) {
          $.tokenError();
        }
        else if (xhr.status >= 400 && xhr.status < 500) {

          $.errorMessage(xhr.responseJSON.message);
        }
        else {
          $.errorMessage(xhr.responseJSON.error)
        }
      }
    });
  });




//   // Search button click event handler
//   $("#myDataTable_filter.dataTables_filter").on("click", function () {
//     var searchTerm = $("#myDataTable_filter.dataTables_filter").val();
//     dataTable.search(searchTerm).draw();
// });






  $("#model").click(function () {
    $("#myModal5").modal("hide");
  });

});