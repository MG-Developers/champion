$(document).ready(function () {


    const token = JSON.parse(localStorage.getItem("token"));
    $("form")[0].reset();
    var test = $.test()

    var product_details = []

    let fieldNames = ['sequenceNumber', 'itemCode', 'description', 'hsn', 'uom', 'quantity', 'unit']

    var total_rows = 0;


    $("#backButton").click((e) => {
        // alert("HI")
        // e.preventDefault(); // Prevent the default form submission
        // Add any additional logic or actions you want here
        window.open("../template/Inbound.jsp", "_self");

    });

    function addRow() {


        let newRow = $(`<tr id="row_${total_rows + 1}">`)

        for (let i = 0; i < fieldNames.length; i++) {
            let cell = $('<td class="text-center p-0">')
            let field = $(`<input type="text" class="form-control px-1 input_size check " required="" id="${fieldNames[i]}_${total_rows + 1}" />`)
            cell.append(field)
            newRow.append(cell)
        }

        let btnCell = $(`<td  class="text-center p-0">
        <button type="button" class="btn btn-outline-danger cancel cancelButton"> Cancel </button> </td>`)
        newRow.append(btnCell)

        $('#product-table tbody').append(newRow)

        total_rows++;
    }


    $("#addButton").on("click", function () {
        let col1 = $(`#s_no_${total_rows}`).val();
        let col2 = $(`#item_code_${total_rows}`).val();
        let col3 = $(`#po_type_${total_rows}`).val();
        let col4 = $(`#description_${total_rows}`).val();
        let col5 = $(`#hsn_${total_rows}`).val();
        let col6 = $(`#uom_${total_rows}`).val();
        let col7 = $(`#quantity_${total_rows}`).val();
        let col8 = $(`#unit_${total_rows}`).val();


        console.log("col1",col1);
        console.log(total_rows);


        // Basic validation
        if (col1 !== "" && col2 !== "" && col3 !== "" && col4 !== "" && col5 !== "" && col6 != "" && col7 != "" && col8 != "") {
            addRow();
        }else {
            // alert("Please Fill Row")
        }

        // addRow()
    })

    

    $("#product-table").on('click', '.cancelButton', function () {
        // Check if there's only one row left in the table
        if ($("#product-table tbody tr").length > 1) {
            // Remove the closest row
            $(this).closest("tr").remove();
            total_rows--;
        } else {
            // Show a message or take some action to indicate that at least one row must remain
            // alert('At least one row must remain in the table!');
        }
    });
    






    function extractTableInputValues() {
        let dataObjects = []

        $('#product-table tbody tr').each(function () {
            let rowData = {}
            $(this).find('input').each(function (index) {
                let columnName = fieldNames[index];
                let cellValue = $(this).val();
                rowData[columnName] = cellValue;
            })
            dataObjects.push(rowData)
        })

        return dataObjects
    }

    $("#inbound_form").submit((e) => {

        // alert("Hi")

        e.preventDefault();
        // Array Data
        product_details = extractTableInputValues();


        var VendorInvoiceNo = $("#invoice_number").val()
        var VendorInvoiceDate = $("#VendorInvoiceDate").val()
        var dcnumber = $("#dcnumber").val()
        var WorkOrderNO = $("#workorderno").val()
        var PONumber = $("#PONumber").val()
        var potype = $("#PO_type").val()
        var Weight = $("#weightquantity").val()
        var InvoiceAmount = $("#InvoiceAmount").val()
        var LRNo = $("#LRNo").val()
        var LRDate = $("#LRDate").val()
        var ContractNo = $("#ContractNo").val()
        var ContractDate = $("#ContractDate").val()
        var State = $("#state").val()
        var EWAYBILL = $("#EWAYBILL").val()
        var IRNNumber = $("#IRNNumber").val()
        var cgstRate = $("#cgstRate").val()
        var cgstAmount = $("#cgstAmount").val()
        var sgstRate = $("#sgstRate").val()
        var sgstAmount = $("#sgstAmount").val()
        var igstRate = $("#igstRate").val()
        var igstAmount = $("#igstAmount").val()
        var cessRate = $("#cessRate").val()
        var cessAmount = $("#cessAmount").val()
        var taxableValue = $("#taxableValue").val()
        var invoiceAmount = $("#invoiceAmount").val()


        $.ajax({
            url: `http://192.168.50.81:8080/ap_automation_backend/ibshipment/add`,
            type: "POST",
            data: JSON.stringify({

                invoiceNumber: VendorInvoiceNo,
                invoiceDate: VendorInvoiceDate,
                deliveryChallanNumber: dcnumber,
                workOrderNumber: WorkOrderNO,
                poNumber: PONumber,
                poType: potype,
                weight: Weight,
                invoiceAmount: InvoiceAmount,
                lrNumber: LRNo,
                lrDate: LRDate,
                contractDate: ContractDate,
                contractNumber: ContractNo,
                state: State,
                ewayBillNumber: EWAYBILL,
                irnNumber: IRNNumber,
                cgstPercentage: cgstRate,
                cgstAmount: cgstAmount,
                sgstPercentage: sgstRate,
                sgstAmount: sgstAmount,
                igstPercentage: igstRate,
                igstAmount: igstAmount,
                cessPercentage: cessRate,
                cessAmount: cessAmount,
                taxableValue: taxableValue,
                ibShipmentDtl: product_details
            }),

            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },

            success: function (data, status, xhr) {

                if (xhr.status == 200) {
                    console.log(data.data);

                    window.open("../template/Inbound.jsp", "_self");
                    $("form")[0].reset();
                }
                else {

                    $.errorMessage(xhr.responseJSON.message);
                    $("form")[0].reset();
                }

            },

            error: function (xhr, httpStatusMessage, customErrorMessage) {

                if (xhr.status == 498) {
                    $.tokenError();
                }
                else if (xhr.status >= 400 && xhr.status < 500) {

                    $.errorMessage(xhr.responseJSON.message);
                    $("form")[0].reset();
                }
                else {
                    $.errorMessage(xhr.responseJSON.error)
                    $("form")[0].reset();
                }

            }
        });

      

       








    });

});
