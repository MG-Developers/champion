$(document).ready(function () {

    
    const token = JSON.parse(localStorage.getItem("token"));
    $("form")[0].reset();
    var test = $.test()

    var product_details = []

    let fieldNames = ['s_no', 'item_code', 'description', 'hsn', 'uom', 'quantity', 'unit']

    var total_rows = 0;

    function addRow() {

        let newRow = $(`<tr id="row_${total_rows + 1}">`)

        for (let i = 0; i < fieldNames.length; i++) {
            let cell = $('<td>')
            let field = $(`<input type="text" class="form-control px-1 input_size check" required="" id="${fieldNames[i]}_${total_rows + 1}" />`)
            cell.append(field)
            newRow.append(cell)
        }

        let btnCell = $(`<td>
        <button type="button" class="btn btn-outline-danger cancel cancelButton"> Cancel </button> </td>`)
        newRow.append(btnCell)

        $('#product-table tbody').append(newRow)

        total_rows++;
    }

    $("#addButton").on("click", function () {
        addRow()
    })

    $("#product-table").on('click', '.cancelButton', function () {
        $(this).closest("tr").remove()
        total_rows--;
    })

    function extractTableInputValues() {
        let dataObjects = []

        $('#product-table tbody tr').each(function () {
            let rowData = {}
            $(this).find('input').each(function (index) {
                let columnName = fieldNames[index];
                let cellValue = $(this).val();
                rowData[columnName] = cellValue;
            })
            dataObjects.push(rowData)
        })

        return dataObjects
    }

    $("#inbound_form").submit((e) => {

        // alert("Hi")

        e.preventDefault();
        // Array Data
        product_details = extractTableInputValues();

      
        var VendorInvoiceNo = $("#invoice_number").val()
        var VendorInvoiceDate = $("#VendorInvoiceDate").val()
        var VendorName = $("#DCNumber").val()
        var WorkOrderNO = $("#workorderno").val()
        var PONumber = $("#PONumber").val()
        var POType = $("#POType").val()
        var Weight = $("#weightquantity").val()
        var InvoiceAmount = $("#InvoiceAmount").val()
        var LRNo = $("#LRNo").val()
        var LRDate = $("#LRDate").val()
        var ContractNo = $("#ContractNo").val()
        var ContractDate = $("#ContractDate").val()
        var State = $("#State").val()
        var EWAYBILL = $("#EWAYBILL").val()
        var IRNNumber = $("#IRNNumber").val()
        var cgstRate = $("#cgstRate").val()
        var cgstAmount = $("#cgstAmount").val()
        var sgstRate = $("#sgstRate").val()
        var sgstAmount = $("#sgstAmount").val()
        var igstRate = $("#igstRate").val()
        var igstAmount = $("#igstAmount").val()
        var cessRate = $("#cessRate").val()
        var cessAmount = $("#cessAmount").val()
        var taxableValue = $("#taxableValue").val()
        var invoiceAmount = $("#invoiceAmount").val()
  

        $.ajax({
            url: `http://192.168.50.81:8080/ap_automation_backend/ibshipment/add`,
            type: "POST",
            data: JSON.stringify({
              
                invoiceNumber: VendorInvoiceNo,
                invoiceDate: VendorInvoiceDate,
                workOrderNumber: WorkOrderNO,
                poNumber: PONumber,
                PoType: POType,
                weight: Weight,
                invoiceAmount: InvoiceAmount,
                lrNumber: LRNo,
                lrDate: LRDate,
                contractDate: ContractDate,
                contractNumber: ContractNo,
                state: State,               
                ewayBillNumber: EWAYBILL,
                irnNumber: IRNNumber,
                cgstPercentage: cgstRate,
                cgstAmount: cgstAmount,
                sgstPercentage: sgstRate,
                sgstAmount: sgstAmount,
                igstPercentage: igstRate,
                igstAmount: igstAmount,
                cessPercentage: cessRate,
                cessAmount: cessAmount,
                taxableValue: taxableValue,
                ibShipmentDtl: product_details
            }),

            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },

            success: function (data, status, xhr) {

                if (xhr.status == 200) {
                    console.log(data.data);

                    window.open("../template/Inbound.jsp", "_self");
                    $("form")[0].reset();
                }
                else {

                    $.errorMessage(xhr.responseJSON.message);
                    $("form")[0].reset();
                }

            },

            error: function (xhr, httpStatusMessage, customErrorMessage) {

                if (xhr.status == 498) {
                    $.tokenError();
                }
                else if (xhr.status >= 400 && xhr.status < 500) {

                    $.errorMessage(xhr.responseJSON.message);
                    $("form")[0].reset();
                }
                else {
                    $.errorMessage(xhr.responseJSON.error)
                    $("form")[0].reset();
                }

            }
        });

        $(".cancel").click((e) => {
            e.preventDefault();
            window.open("../template/inbound.jsp", "_self");
        })
    });
});
