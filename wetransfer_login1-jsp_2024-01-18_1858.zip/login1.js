$(document).ready(function() {
    let test = $.testUrl();
	let login = $.loginUrl();

    // Add click event listener to login button
   
    $("#myForm").submit(function (event) {
        alert(hello)
        event.preventDefault();
        // Get values from input fields
        var username = $("input[name='username']").val();
        var password = $("input[name='password']").val();

        // Perform AJAX request to handle login
        $.ajax({
            url: `${[test[0].url]}/auth/signin`, // Change to your server-side script
            type: "POST",
            data: { username: username, password: password },
            success: function(response) {
                // Handle the response from the server
                // window.location.href = "dashboard.html";
                alert(response); // Display a message or redirect as needed
            },
            error: function(xhr, status, error) {
                // Handle errors
                console.error(xhr.responseText);
            }
        });
    });


   
});
