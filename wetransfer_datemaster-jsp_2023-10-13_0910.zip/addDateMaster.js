$(document).ready(() => {
    const token = JSON.parse(localStorage.getItem("token"));
    $("form")[0].reset();
    let test = $.test();



    $("#saveDate").click(function(){
        var dateString = $("#date").val();
           
    
            // Display SweetAlert confirmation
            Swal.fire({
              title: 'Confirm Save',
              text: `Are you sure you want to save the date: ${dateString}?`,
              icon: 'question',
              showCancelButton: true,
              confirmButtonText: 'Yes, save it!',
              cancelButtonText: 'No, cancel!',
            }).then((result) => {
                
              // Check if the user clicked "Yes"
              if (result.isConfirmed) {
    
                // Example: Display the date in the console
                console.log("Saving date:", dateString);
    
         
                 $.ajax({
                   url: "http://192.168.50.81:8080/ap_automation_backend/dateFormat/add",
                   method: "POST",
                   data:  JSON.stringify({
                    dateFormat: dateString,
                 
                  }),
            
                   success: function(response) {
                    // window.open("../template/dateMaster.jsp", "_self");

                   console.log("Date saved successfully");
               },
                   error: function(error) {
                   console.error("Error saving date:", error);
                   }
                });
              
                // Display success message
                Swal.fire('Saved!', 'Date has been saved successfully.', 'success');
                // window.location.href("../template/dateMaster.jsp");
              } else {
                // Display cancel message
                Swal.fire('Cancelled', 'Date not saved.', 'info');
              }
            });
        

        


    })
     
  });