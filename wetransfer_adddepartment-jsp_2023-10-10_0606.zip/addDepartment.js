$(document).ready(() => {


     // Fetch and set value on modal button click
     var eaemail = $('#eaemail').val();
     $('#emailadd').on('click', function(){
       // Fetch the value of modal input

       // Set the value into the target input
       $('#emailname').val(eaemail);

       $('#myModal5').show();
       // Close the modal
       $('#myModal5').hide();
   });


    // Fetch and set value on modal button click
    var hodemail = $('#hodemail').val();
    $('#addemail1').on('click', function(){
      // Fetch the value of modal input

      // Set the value into the target input
      $('#emailname1').val(hodemail);

      $('#myModal6').show();


      // Close the modal
      $('#myModal6').hide();
  });





  $('#eaemail').hide();
  $('#addemail').hide();

  // Bind an event handler to the change event of the dropdown
  $('#ea').change(function(){

      // Check the selected value
      var selectedValue = $("#ea").val(); 
      // If "No" is selected, hide the input field  with button; otherwise, show it
      if(selectedValue === 'N'){
        
          $('#eaemail').hide();
          $("#addemail").hide();
      } else {
          $('#eaemail').show();
          $("#addemail").show();

      }
  });
    $('#hodemail').hide();
    $('#addemail1').hide();


  $('#hod').change(function(){

    // Check the selected value
    var selectedValue = $("#hod").val(); 
    // If "No" is selected, hide the input field  with button; otherwise, show it
    if(selectedValue === 'N'){

        $('#hodemail').hide();
          $("#addemail1").hide();
    } else {
        $('#hodemail').show();
          $("#addemail1").show();

    }
});

    const token = JSON.parse(localStorage.getItem("token"));
      $("form")[0].reset();
      let test = $.test();
      let emailArr = []
      let selectFilter;




    //   $("#DropDown").filterMultiSelect({
    //     placeholderText: "Nothing Selected"
    //   });

    //   let emailValues =[]
    //   let newOption1;

    //   $("#addemail").click(function () {
    

    //     let emailVal = $("#email").val();

    //     if (emailVal !== "") {

    //       if(emailValues.includes(emailVal) == false)
    //       {
    //         newOption1 = []
    //         emailValues.push(emailVal)

    //         console.log("entered");
    //         $('#DropDown').remove();
    //         emailValues.map((values)=> {
    //           console.log(values);
    //           newOption1.push($('<option>', { value: `${values}`, text: `${values}` }));
    //         })
            
    //           // $("#DropDown").append(`<option value="${emailVal}">${emailVal}</option>`)
    //           $("#email").val("")
    //           // emailArr.push({ 'email': emailVal });
    //           $("#dropId").append(`<select id="DropDown" name="emails" multiple class="form-control">
    //           </select>`)
    //           $('#DropDown').append(...newOption1)
    //            selectFilter = $("#DropDown").filterMultiSelect({
    //             placeholderText: "Nothing Selected"
    //           })

    //           selectFilter.selectAll()
    //       }

    //     }
    // });


   



      $('#form').submit(function (e) {

        
        
          e.preventDefault();
          let values  = selectFilter.getSelectedOptionsAsJson(includeDisabled=true);

              JSON.parse(values).emails.map(values => {
                emailArr.push({email : values});
              })

          var departmentcode = $("#departmentcode").val()
          var departmentname = $("#departmentname").val()
          var ea = $('#ea option:selected').val();
            var hod = $("#hod").val()
          var naming = $('#name').val();
          // var emailname= $('#emailname').val();
          
          

       
        $.ajax({
          url: `${[test[0].url]}/department/add`,
          type: "POST",
          data: JSON.stringify({

            departmentCode: departmentcode,
            departmentName: departmentname,
            e_A: ea,
            hod: hod,
            name: naming,
            emails: emailArr


          
            
          }),

          headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
              'Authorization': 'Bearer '+ token
          },

          success: function (data, status, xhr) {
              console.log(data);
             

              if (xhr.status == 200) {
                  window.open("../template/department.jsp", "_self");
                  $("form")[0].reset();
              }
              else{

                $.errorMessage(xhr.responseJSON.message);
              }
          },

          error: function (xhr, httpStatusMessage, customErrorMessage) {

            if(xhr.status == 498)
            {
                $.tokenError();
            }
            else if(xhr.status >= 400 && xhr.status < 500){

              $.errorMessage(xhr.responseJSON.message);
              $("form")[0].reset();
            }
            else{
              $.errorMessage(xhr.responseJSON.error)
              $("form")[0].reset();
            }
          }
      });

      
         
  
      });
  
   
      
       
      $(".cancel").click((e) => {
          e.preventDefault();
          window.open("../template/department.jsp", "_self");
      })
  
  });
  