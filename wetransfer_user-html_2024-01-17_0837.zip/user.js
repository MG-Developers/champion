

$(function() {

    const token = JSON.parse(localStorage.getItem("token"));
    // Set the number of visible page numbers in the DataTable pager
    $.fn.DataTable.ext.pager.numbers_length = 5;

    // Get the required elements
    const $Dtable = $('#Dtable');
    const $col1_filter = $('#col1_filter');

    // Perform a [test[0].url]
    // var test = $.test();
    

    // Initialize the DataTable
    const tab = $Dtable.DataTable({
        // Define the DOM structure for the DataTable
        dom: '<"top"f>t<"bottom"ilp>',
        ordering: true,
        processing: true,
        ajax: {
            // Specify the URL for data retrieval
            url: `https://dummyjson.com/users`,
            dataSrc: "data",
            headers: {
                'Authorization': 'Bearer ' + token,
              },
              error: function (xhr) {
                
                if(xhr.status == 498)
                {
                    $.tokenError();
                }
                else if(xhr.status >= 400 && xhr.status < 500){

                        $.errorMessage(xhr.responseJSON.message);
                }
                else{
                        $.errorMessage(xhr.responseJSON.error)
                }
            },
            complete: () => {
                // Remove loader and spinner when data loading is complete
                $("#loader").removeClass("sk-loading ibox-content");
                $(".sk-spinner").addClass("d-none");
            }
        },
        columns: [
            // Specify the data columns for the DataTable
            { data: "id" },
            { data: "username"},
            { data: "firstName" },
            { data: "lastName" },
            { data: "email" },
            {
                data: "id",
                render: function (data, type, row, meta) {
                    // Render buttons for delete, edit, and view actions
                    return `
                        <div class="btn-group">
                            <button class='btn btn-outline-danger btn-sm delete'>Delete</button>&nbsp;&nbsp;  
                            <button class='btn btn-outline-success btn-sm edit'>Edit</button>&nbsp;&nbsp;
                            <button class='btn btn-outline-primary btn-sm view'>View</button>
                        </div>
                    `;
                }
            }
        ],
        columnDefs: [
            // Set default content for all columns
            { "defaultContent": "-", "targets": "_all" },
            // Set priority for responsive columns
            { responsivePriority: 1, targets: 0 },
            { responsivePriority: -2, targets: 4 }
        ]
    });

    // Hide the first column (userid)
    tab.column(0).visible(false);
 
});

