$(document).ready(() => {

    const token = JSON.parse(localStorage.getItem("token"));
    $("form")[0].reset();
    const d = new Date();
    var test = $.test()
    $('#form').submit(function (e) {
        e.preventDefault();

        var vendorCode = $("#vendorCode").val()
        var VendorName = $("#vendorname").val()
        var VendorInvoiceNo = $("#Vendor InvoiceNo").val()
        var VendorInvoiceDate = $("#VendorInvoiceDate").val()
        var VendorName = $("#DCNumber").val()
        var WorkOrderNO = $("#workorderno").val()
        var PONumber = $("#PONumber").val()
        var POType = $("#POType").val()
        var Weight = $("#weightqunatity").val()
        var InvoiceAmount= $("#InvoiceAmount").val()
        var UnitName = $("#UnitName").val()
        var StoreId = $("#StoreId").val()   
        var TransactionType = $("#TransactionType").val()
        var Invoiceno = $("#Invoiceno").val()
        var LRDate= $("#LRDate").val()
        var LRNo= $("#LRNo").val()
        var ContractDate= $("#ContractDate").val()
        var ContractNo= $("#ContractNo").val()
        var State = $("#State").val()
        var Weight= $("#Weight").val()  
        var VehicleNumber= $("#VehicleNumber").val()
        var PoNumber = $("#PoNumber").val()   
        var PoType = $("#PoType").val()
        var EWAYBILL = $("#EWAYBILL").val()
        var IRNNumber= $("#IRNNumber").val()
        var cgstRate= $("#cgstRate").val()
        var cgstAmount= $("#cgstAmount").val()
        var sgstRate= $("#sgstRate").val()
        var sgstAmount= $("#sgstAmount").val()
        var igstRate = $("#igstRate").val()
        var igstAmount= $("#igstAmount").val()  
        var cessRate = $("#cessRate").val()
        var cessAmount= $("#cessAmount").val()
        var taxableValue= $("#taxableValue").val()
        var invoiceAmount=$("#invoiceAmount").val()
        var sgstRate= $("#sgstRate").val()
        var igstRate = $("#igstRate").val()
        var invoiceAmount= $("#invoiceAmount").val()  

        $.ajax({
            url: `https:localhost:8050/ibshipment/add`,
            type: "POST",
            data: JSON.stringify({
                code: vendorCode,
                description: VendorName,
                label: VendorInvoiceNo ,
                label: VendorInvoiceDate,
                label: VendorName,
                label: WorkOrderNO,
                label: PONumber,
                label:  POType,
                label:  Weight,
                label:  InvoiceAmount,
                label: UnitName,
                label:  StoreId,
                label: ansactionType,
                label: TransactionType,
                label: Invoiceno,
                label: LRDate,
                label: LRNo,
                label: ContractDate,
                label: ContractNo,
                label: State,
                label: Weight,
                label: VehicleNumber,
                label: PoNumber,
                label: PoType ,
                label: EWAYBILL,
                label: IRNNumber,
                label: cgstRate,
                label: cgstAmount,
                label: sgstRate,
                label: sgstAmount,
                label: igstRate ,
                label: igstAmount,
                label: cessRate,
                label: cessAmount,
                label: taxableValue,
                label: invoiceAmount,
                label: sgstRa,te,
                label:  igstRate,
                label:  invoiceAmount

= 
            }),

            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },

            success: function (data, status, xhr) {

                if (xhr.status == 200) {
                    window.open("../template/inbound.jsp", "_self");
                    $("form")[0].reset();
                }
                else{
                    
                    $.errorMessage(xhr.responseJSON.message);
                    $("form")[0].reset();
                }
                
            },

            error: function (xhr, httpStatusMessage, customErrorMessage) {

                if(xhr.status == 498)
                {
                    $.tokenError();
                }
                else if(xhr.status >= 400 && xhr.status < 500){

                        $.errorMessage(xhr.responseJSON.message);
                        $("form")[0].reset();
                }
                else{
                        $.errorMessage(xhr.responseJSON.error)
                        $("form")[0].reset();
                }

            }
        });

    });

    $(".cancel").click((e) => {
        e.preventDefault();
        window.open("../template/inbound.jsp", "_self");
    })

});
